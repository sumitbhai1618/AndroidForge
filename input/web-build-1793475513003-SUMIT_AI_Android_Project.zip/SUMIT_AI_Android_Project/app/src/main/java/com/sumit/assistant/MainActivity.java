package com.sumit.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.speech.tts.TextToSpeech;
import android.widget.Button;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.graphics.Color;
import android.hardware.camera2.CameraManager;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status;
    private SpeechRecognizer recognizer;
    private TextToSpeech tts;
    private boolean torchOn = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(0);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(28, 40, 28, 40);
        layout.setBackgroundColor(Color.rgb(5, 10, 24));

        TextView title = new TextView(this);
        title.setText("SUMIT AI");
        title.setTextColor(Color.CYAN);
        title.setTextSize(34);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        status = new TextView(this);
        status.setText("નમસ્તે! હું SUMIT છું.\nમાઇક્રોફોન દબાવીને બોલો.");
        status.setTextColor(Color.WHITE);
        status.setTextSize(18);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, 35, 0, 35);
        layout.addView(status);

        Button listen = new Button(this);
        listen.setText("🎙 બોલો — SUMIT સાંભળે છે");
        layout.addView(listen);
        setContentView(layout);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("gu", "IN"));
        });

        listen.setOnClickListener(v -> startListening());
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
        }
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("તમારા ફોનમાં વોઇસ ઓળખવાની સુવિધા ઉપલબ્ધ નથી.");
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            public void onReadyForSpeech(Bundle p) { status.setText("હા, બોલો..."); }
            public void onBeginningOfSpeech() { }
            public void onRmsChanged(float r) { }
            public void onBufferReceived(byte[] b) { }
            public void onEndOfSpeech() { status.setText("સમજી રહ્યો છું..."); }
            public void onError(int e) { status.setText("ફરી માઇક્રોફોન દબાવીને બોલો."); }
            public void onResults(Bundle r) {
                ArrayList<String> a = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (a != null && !a.isEmpty()) runCommand(a.get(0).toLowerCase(Locale.ROOT));
            }
            public void onPartialResults(Bundle p) { }
            public void onEvent(int t, Bundle p) { }
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "gu-IN");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "gu-IN");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "SUMIT ને કહો...");
        recognizer.startListening(i);
    }

    private void runCommand(String s) {
        status.setText("તમે કહ્યું: " + s);
        if (s.contains("ઇન્સ્ટાગ્રામ") || s.contains("instagram")) {
            openApp("com.instagram.android", "Instagram");
        } else if (s.contains("વોટ્સએપ") || s.contains("whatsapp")) {
            openApp("com.whatsapp", "WhatsApp");
        } else if (s.contains("યૂટ્યુબ") || s.contains("youtube")) {
            openApp("com.google.android.youtube", "YouTube");
        } else if (s.contains("કેમેરા") || s.contains("camera")) {
            startActivity(new Intent("android.media.action.IMAGE_CAPTURE"));
            say("કેમેરો ખોલું છું.");
        } else if (s.contains("ટોર્ચ ચાલુ") || s.contains("flashlight on")) {
            setTorch(true);
        } else if (s.contains("ટોર્ચ બંધ") || s.contains("flashlight off")) {
            setTorch(false);
        } else if (s.contains("વોલ્યુમ વધારો") || s.contains("volume up")) {
            AudioManager am = (AudioManager)getSystemService(AUDIO_SERVICE);
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
            say("વોલ્યુમ વધાર્યું.");
        } else if (s.contains("એલાર્મ") || s.contains("alarm")) {
            Intent alarm = new Intent(AlarmClock.ACTION_SET_ALARM);
            alarm.putExtra(AlarmClock.EXTRA_HOUR, 7);
            alarm.putExtra(AlarmClock.EXTRA_MINUTES, 0);
            alarm.putExtra(AlarmClock.EXTRA_MESSAGE, "SUMIT AI");
            if (alarm.resolveActivity(getPackageManager()) != null) startActivity(alarm);
            say("સાત વાગ્યાનું એલાર્મ સેટ કરવા ખોલું છું.");
        } else if (s.contains("ફોન") || s.contains("કોલ") || s.contains("call")) {
            startActivity(new Intent(Intent.ACTION_DIAL));
            say("કોલ કરવા માટે ડાયલર ખોલું છું.");
        } else {
            say("માફ કરશો, આ કમાન્ડ હજુ શીખ્યો નથી.");
        }
    }

    private void openApp(String pkg, String name) {
        Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
        if (i != null) { startActivity(i); say(name + " ખોલું છું."); }
        else say(name + " એપ મળી નથી.");
    }

    private void setTorch(boolean on) {
        try {
            CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
            String[] ids = cm.getCameraIdList();
            for (String id : ids) {
                if (cm.getCameraCharacteristics(id).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)) {
                    cm.setTorchMode(id, on);
                    torchOn = on;
                    say(on ? "ટોર્ચ ચાલુ કરી." : "ટોર્ચ બંધ કરી.");
                    return;
                }
            }
            say("આ ફોનમાં ટોર્ચ ઉપલબ્ધ નથી.");
        } catch (Exception e) { say("ટોર્ચ ચાલુ થઈ નથી."); }
    }

    private void say(String text) {
        status.setText(text);
        if (tts != null) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sumit");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
